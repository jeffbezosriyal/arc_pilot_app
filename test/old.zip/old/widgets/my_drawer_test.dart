import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:machine_dashboard/api/api_service.dart';
import 'package:machine_dashboard/models/job.dart';
import 'package:machine_dashboard/screens/job_management/job_management_page.dart';
import 'package:machine_dashboard/screens/machine_settings/machine_settings_page.dart';
import 'package:machine_dashboard/utils/app_theme.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

import 'my_drawer_test.mocks.dart';

// Generate a mock for ApiService
@GenerateMocks([ApiService])
void main() {
  late MockApiService mockApiService;

  setUp(() {
    mockApiService = MockApiService();
  });

  // A robust helper function to build the app with all necessary dependencies
  Widget createWidgetUnderTest({String initialRoute = '/'}) {
    when(mockApiService.fetchJobs()).thenAnswer((_) async => <Job>[]);

    return MaterialApp(
      theme: ThemeData(
        extensions: const <ThemeExtension<dynamic>>[
          CustomSettingsTheme(
            switchActiveColor: Colors.blue,
            switchInactiveThumbColor: Colors.grey,
            switchInactiveTrackColor: Colors.black,
          ),
        ],
      ),
      initialRoute: initialRoute,
      // FIX: The routes should point directly to your page widgets.
      // Your pages already have their own Scaffold, so we remove the wrapper here.
      routes: {
        '/': (context) => const MachineSettingsPage(),
        '/job-management': (context) =>
            JobManagementPage(apiService: mockApiService),
      },
    );
  }

  group('MyDrawer Widget Tests', () {
    testWidgets('renders all navigation items correctly',
            (WidgetTester tester) async {
          await tester.pumpWidget(createWidgetUnderTest());

          // Find and tap the single, correct menu icon to open the drawer.
          await tester.tap(find.byTooltip('Open navigation menu'));
          await tester.pumpAndSettle();

          expect(find.text('ArcPilot™'), findsOneWidget);
          expect(find.text('Transmax XP6 200i'), findsOneWidget);
          expect(find.text('Device Page'), findsOneWidget);
          expect(find.text('Job management'), findsOneWidget);
          expect(find.text('Arc on Metric'), findsOneWidget);
          expect(find.text('Machine Setting'), findsOneWidget);
          expect(find.text('Exit Device'), findsOneWidget);
        });

    testWidgets('tapping "Job management" navigates to the correct page',
            (WidgetTester tester) async {
          await tester.pumpWidget(createWidgetUnderTest());

          await tester.tap(find.byTooltip('Open navigation menu'));
          await tester.pumpAndSettle();

          expect(find.byType(JobManagementPage), findsNothing);

          await tester.tap(find.text('Job management'));
          await tester.pumpAndSettle();

          expect(find.byType(JobManagementPage), findsOneWidget);
        });

    testWidgets('tapping "Machine Setting" navigates back to the home page',
            (WidgetTester tester) async {
          await tester.pumpWidget(
              createWidgetUnderTest(initialRoute: '/job-management'));

          await tester.tap(find.byTooltip('Open navigation menu'));
          await tester.pumpAndSettle();

          expect(find.byType(MachineSettingsPage), findsNothing);

          await tester.tap(find.text('Machine Setting'));
          await tester.pumpAndSettle();

          expect(find.byType(MachineSettingsPage), findsOneWidget);
        });

    testWidgets(
        'active route ("Machine Setting") is highlighted when on the home page',
            (WidgetTester tester) async {
          await tester.pumpWidget(createWidgetUnderTest());

          await tester.tap(find.byTooltip('Open navigation menu'));
          await tester.pumpAndSettle();

          final tileContainer = tester.widget<Container>(find.byWidgetPredicate(
                (widget) =>
            widget is Container &&
                (widget.child is ListTile &&
                    (widget.child as ListTile).title is Text &&
                    ((widget.child as ListTile).title as Text).data ==
                        'Machine Setting'),
          ));

          expect(tileContainer.color, Colors.blue);
        });
  });
}