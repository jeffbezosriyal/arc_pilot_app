import 'package:flutter_test/flutter_test.dart';
import 'package:machine_dashboard/models/job.dart';

// CRITICAL FIX: Every test file must have a main() function.
void main() {
  group('Job Model Tests', () {
    // A complete JSON sample from the API.
    final Map<String, dynamic> jobJson = {
      '_id': '670c8853291f52642a882357',
      'title': 'Sample Job',
      'mode': 'MIG',
      'current': '120A',
      'hotStartTime': '0.5s',
      'wave': 'Standard',
      'base': '50A',
      'pulse': '100Hz',
      'duty': '50%',
      'wire': 'Steel',
      'shieldingGas': 'Argon',
      'arcLength': '1.0',
      'diameter': '0.8mm',
      'inductance': '3.0',
      'isActive': true,
    };

    test('fromJson should correctly parse a complete JSON object', () {
      // ACT: Create a Job instance from the JSON.
      final job = Job.fromJson(jobJson);

      // ASSERT: Verify all fields are parsed correctly.
      expect(job.id, '670c8853291f52642a882357');
      expect(job.title, 'Sample Job');
      expect(job.mode, 'MIG');
      expect(job.current, '120A');
      expect(job.isActive, isTrue);
    });

    test('fromJson should handle missing optional fields gracefully', () {
      // ARRANGE: A JSON object with only the required fields.
      final minimalJson = {
        '_id': '123',
        'title': 'Minimal Job',
        'mode': 'TIG',
        'current': '80A',
      };

      // ACT
      final job = Job.fromJson(minimalJson);

      // ASSERT: Verify required fields are set and optional fields default to empty strings.
      expect(job.id, '123');
      expect(job.title, 'Minimal Job');
      expect(job.hotStartTime, ''); // Should default to an empty string, not null.
      expect(job.isActive, isFalse); // Should default to false.
    });

    test('toJson should produce a correct JSON map for API submission', () {
      // ARRANGE: Create a Job instance to be converted to JSON.
      final job = Job(
        title: 'New Job to Send',
        mode: 'MIG DP',
        current: '150A',
        wire: 'Alu',
        isActive: false,
      );

      // ACT
      final jsonOutput = job.toJson();

      // ASSERT: Verify the output map.
      expect(jsonOutput['title'], 'New Job to Send');
      expect(jsonOutput['mode'], 'MIG DP');
      // IMPORTANT: The 'id' key should not be present when creating a new job.
      expect(jsonOutput.containsKey('id'), isFalse);
    });
  });
}