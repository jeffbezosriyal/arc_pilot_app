import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:machine_dashboard/screens/machine_settings/machine_settings_page.dart';
import 'package:machine_dashboard/screens/machine_settings/widgets/bottom_sheets.dart';
import 'package:machine_dashboard/screens/machine_settings/widgets/settings_widgets.dart';
import 'package:machine_dashboard/utils/app_theme.dart';

void main() {
  Widget createWidgetUnderTest() {
    return MaterialApp(
      theme: ThemeData(
        extensions: const <ThemeExtension<dynamic>>[
          CustomSettingsTheme(
            switchActiveColor: Colors.blue,
            switchInactiveThumbColor: Colors.grey,
            switchInactiveTrackColor: Colors.black,
          ),
        ],
      ),
      home: const MachineSettingsPage(),
    );
  }

  group('MachineSettingsPage Widget Tests', () {
    testWidgets('renders correctly with initial state and all child widgets',
            (WidgetTester tester) async {
          await tester.pumpWidget(createWidgetUnderTest());
          await tester.pump();

          expect(find.text('Machine Settings'), findsOneWidget);
          expect(find.text('Transmax XP6'), findsOneWidget);
          expect(find.textContaining('Series ID: 489131GBBW8'), findsOneWidget);
          expect(find.text('Beeper'), findsOneWidget);
          expect(find.text('Beeper is on'), findsOneWidget);
          expect(find.text('Unit'), findsOneWidget);
          expect(find.text('Unit is mm'), findsOneWidget);
          expect(
              find.byWidgetPredicate((widget) =>
              widget is Text &&
                  widget.data == 'Robot Connection' &&
                  widget.style?.fontWeight == FontWeight.bold),
              findsOneWidget);
          expect(
              find.byWidgetPredicate((widget) =>
              widget is Text &&
                  widget.data == 'Information' &&
                  widget.style?.fontWeight == FontWeight.bold),
              findsOneWidget);
          expect(
              find.byWidgetPredicate((widget) =>
              widget is Text &&
                  widget.data == 'Factory Reset' &&
                  widget.style?.fontWeight == FontWeight.bold),
              findsOneWidget);
          expect(
              find.byWidgetPredicate((widget) =>
              widget is Text &&
                  widget.data == 'Program Update' &&
                  widget.style?.fontWeight == FontWeight.bold),
              findsOneWidget);
          expect(find.text('Delete the machine'), findsOneWidget);
        });

    testWidgets('toggles Beeper switch and updates its subtitle text',
            (WidgetTester tester) async {
          await tester.pumpWidget(createWidgetUnderTest());
          expect(find.text('Beeper is on'), findsOneWidget);

          final beeperTileFinder = find.widgetWithText(SettingsTile, 'Beeper');
          final beeperSwitchFinder =
          find.descendant(of: beeperTileFinder, matching: find.byType(Switch));

          await tester.tap(beeperSwitchFinder);
          await tester.pump();

          expect(find.text('Beeper is on'), findsNothing);
          expect(find.text('Beeper is off'), findsOneWidget);
        });

    testWidgets('toggles Unit switch and updates its subtitle text',
            (WidgetTester tester) async {
          await tester.pumpWidget(createWidgetUnderTest());
          expect(find.text('Unit is mm'), findsOneWidget);

          final unitTileFinder = find.widgetWithText(SettingsTile, 'Unit');
          final unitSwitchFinder =
          find.descendant(of: unitTileFinder, matching: find.byType(Switch));

          await tester.tap(unitSwitchFinder);
          await tester.pump();

          expect(find.text('Unit is mm'), findsNothing);
          expect(find.text('Unit is inch'), findsOneWidget);
        });

    testWidgets('tapping Rename button opens the RenameMachineSheet',
            (WidgetTester tester) async {
          await tester.pumpWidget(createWidgetUnderTest());
          expect(find.byType(RenameMachineSheet), findsNothing);
          await tester.tap(find.text('Rename'));
          await tester.pumpAndSettle();
          expect(find.byType(RenameMachineSheet), findsOneWidget);
          expect(find.text('Enter new machine name'), findsOneWidget);
        });

    testWidgets('clock display in settings tile updates after one second',
            (tester) async {
          // ARRANGE
          await tester.pumpWidget(createWidgetUnderTest());
          await tester.pump(); // Settle the initial frame.

          final timeFinder = find.byWidgetPredicate((widget) =>
          widget is Text &&
              widget.data != null &&
              RegExp(r'Time is \d{2}:\d{2}:\d{2} (AM|PM)').hasMatch(widget.data!));

          final initialTimeText = (tester.widget(timeFinder) as Text).data!;

          // ACT: Advance the clock by one second. This command also triggers a
          // rebuild, which will render the updated state from the timer.
          await tester.pump(const Duration(seconds: 1));

          // ASSERT
          final updatedTimeText = (tester.widget(timeFinder) as Text).data!;
          expect(updatedTimeText, isNot(initialTimeText));
        });
  });
}