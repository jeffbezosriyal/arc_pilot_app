import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:machine_dashboard/screens/machine_settings/widgets/bottom_sheets.dart';

void main() {
  // Helper to display a bottom sheet for testing.
  Future<void> showTestBottomSheet(WidgetTester tester, Widget sheet) async {
    await tester.pumpWidget(MaterialApp(
      home: Scaffold(
        body: Builder(
          builder: (BuildContext context) {
            return Center(
              child: ElevatedButton(
                child: const Text('Show Sheet'),
                onPressed: () {
                  showModalBottomSheet<void>(
                    context: context,
                    isScrollControlled: true,
                    builder: (_) => sheet,
                  );
                },
              ),
            );
          },
        ),
      ),
    ));

    await tester.tap(find.text('Show Sheet'));
    await tester.pumpAndSettle(); // Wait for animation to finish.
  }

  group('RenameMachineSheet Tests', () {
    testWidgets('renders correctly and calls onSave when valid name is entered',
            (WidgetTester tester) async {
          String? savedName;
          // ARRANGE: Show the bottom sheet with a callback to capture the saved name.
          await showTestBottomSheet(
            tester,
            RenameMachineSheet(
              currentName: 'Old Name',
              onSave: (newName) {
                savedName = newName;
              },
            ),
          );

          // ASSERT: Verify initial state.
          expect(find.text('Rename the machine'), findsOneWidget);
          expect(find.widgetWithText(TextField, 'Old Name'), findsOneWidget);

          // ACT: Enter a new name and tap 'Save'.
          await tester.enterText(find.byType(TextField), 'New Machine Name');
          await tester.tap(find.widgetWithText(ElevatedButton, 'Save'));
          await tester.pumpAndSettle();

          // ASSERT: Verify the sheet is closed and the onSave callback was called.
          expect(find.byType(RenameMachineSheet), findsNothing);
          expect(savedName, 'New Machine Name');
        });

    testWidgets('shows error when trying to save with an empty name',
            (WidgetTester tester) async {
          // ARRANGE
          await showTestBottomSheet(
            tester,
            RenameMachineSheet(currentName: 'Old Name', onSave: (_) {}),
          );

          // ACT: Clear the text field and tap 'Save'.
          await tester.enterText(find.byType(TextField), '');
          await tester.tap(find.widgetWithText(ElevatedButton, 'Save'));
          await tester.pump(); // Rebuild for error text.

          // ASSERT: Verify the error message is displayed and the sheet remains open.
          expect(find.text('Machine name cannot be empty'), findsOneWidget);
          expect(find.byType(RenameMachineSheet), findsOneWidget);
        });

    testWidgets('tapping Cancel closes the sheet without calling onSave',
            (WidgetTester tester) async {
          bool onSaveCalled = false;
          // ARRANGE
          await showTestBottomSheet(
            tester,
            RenameMachineSheet(
              currentName: 'Old Name',
              onSave: (_) {
                onSaveCalled = true;
              },
            ),
          );

          // ACT
          await tester.tap(find.widgetWithText(OutlinedButton, 'Cancel'));
          await tester.pumpAndSettle();

          // ASSERT
          expect(find.byType(RenameMachineSheet), findsNothing);
          expect(onSaveCalled, isFalse);
        });
  });

  group('Confirmation and Status Sheets Tests', () {
    testWidgets('ResetConfirmationSheet renders and its buttons are tappable',
            (WidgetTester tester) async {
          // ARRANGE
          await showTestBottomSheet(tester, const ResetConfirmationSheet());

          // ASSERT
          expect(find.text('Reset Machine Settings'), findsOneWidget);
          expect(find.textContaining('This will restore all machine settings'),
              findsOneWidget);

          // ACT & ASSERT: Test the cancel button.
          await tester.tap(find.widgetWithText(OutlinedButton, 'Cancel'));
          await tester.pumpAndSettle();
          expect(find.byType(ResetConfirmationSheet), findsNothing);
        });

    testWidgets(
        'RemoveMachineConfirmationSheet renders and its buttons are tappable',
            (WidgetTester tester) async {
          // ARRANGE
          await showTestBottomSheet(tester, const RemoveMachineConfirmationSheet());

          // ASSERT
          expect(find.text('Remove Machine'), findsOneWidget);
          expect(find.textContaining('This action cannot be undone'), findsOneWidget);

          // ACT & ASSERT: Test the remove button.
          await tester.tap(find.widgetWithText(ElevatedButton, 'Remove'));
          await tester.pumpAndSettle();
          expect(find.byType(RemoveMachineConfirmationSheet), findsNothing);
        });

    testWidgets('ResetSuccessSheet renders its static content',
            (WidgetTester tester) async {
          // ARRANGE
          await showTestBottomSheet(tester, const ResetSuccessSheet());

          // ASSERT
          expect(find.text('Reset successful!'), findsOneWidget);
          expect(find.byIcon(Icons.check_circle), findsOneWidget);
        });

    testWidgets('ResetFailedSheet renders its static content',
            (WidgetTester tester) async {
          // ARRANGE
          await showTestBottomSheet(tester, const ResetFailedSheet());

          // ASSERT
          expect(find.text('Reset failed!'), findsOneWidget);
          expect(find.byIcon(Icons.cancel), findsOneWidget);
        });
  });
}
