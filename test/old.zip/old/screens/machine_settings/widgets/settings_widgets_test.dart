import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:machine_dashboard/screens/machine_settings/widgets/settings_widgets.dart';

void main() {
  // Helper to wrap a widget in MaterialApp for proper rendering.
  Widget buildTestableWidget(Widget child) {
    return MaterialApp(
      home: Scaffold(
        body: child,
      ),
    );
  }

  group('SettingsTile Widget Tests', () {
    testWidgets('renders correctly with all properties',
            (WidgetTester tester) async {
          // ARRANGE
          await tester.pumpWidget(buildTestableWidget(
            const SettingsTile(
              icon: Icons.wifi,
              title: 'Test Title',
              subtitle: 'Test Subtitle',
              trailing: Icon(Icons.arrow_forward),
            ),
          ));

          // ASSERT
          expect(find.byIcon(Icons.wifi), findsOneWidget);
          expect(find.text('Test Title'), findsOneWidget);
          expect(find.text('Test Subtitle'), findsOneWidget);
          expect(find.byIcon(Icons.arrow_forward), findsOneWidget);
        });

    testWidgets('renders correctly without optional subtitle',
            (WidgetTester tester) async {
          // ARRANGE
          await tester.pumpWidget(buildTestableWidget(
            const SettingsTile(
              icon: Icons.wifi,
              title: 'Test Title',
              trailing: Icon(Icons.arrow_forward),
            ),
          ));

          // ASSERT
          expect(find.text('Test Title'), findsOneWidget);
          // Verify subtitle is not present.
          expect(find.text('Test Subtitle'), findsNothing);
        });

    testWidgets('renders correctly without optional trailing widget',
            (WidgetTester tester) async {
          // ARRANGE
          await tester.pumpWidget(buildTestableWidget(
            const SettingsTile(
              icon: Icons.wifi,
              title: 'Test Title',
              subtitle: 'Test Subtitle',
            ),
          ));

          // ASSERT
          expect(find.text('Test Title'), findsOneWidget);
          // Verify trailing widget is not present.
          expect(find.byIcon(Icons.arrow_forward), findsNothing);
        });
  });

  group('Section Widget Tests', () {
    testWidgets('RobotConnectionWidget renders its static content',
            (WidgetTester tester) async {
          await tester.pumpWidget(buildTestableWidget(const RobotConnectionWidget()));

          expect(find.text('Status'), findsOneWidget);
          expect(find.text('Robot is connected'), findsOneWidget);
          expect(find.text('Reset'), findsOneWidget);
        });

    testWidgets('InformationWidget renders its static content',
            (WidgetTester tester) async {
          await tester.pumpWidget(buildTestableWidget(const InformationWidget()));

          expect(find.text('Device Model'), findsOneWidget);
          expect(find.text('Model X100'), findsOneWidget);
          expect(find.text('Serial Number'), findsOneWidget);
          expect(find.text('Firmware'), findsOneWidget);
        });

    testWidgets('FactoryResetWidget renders its static content and button',
            (WidgetTester tester) async {
          await tester.pumpWidget(buildTestableWidget(const FactoryResetWidget()));

          expect(find.text('Factory Reset'), findsOneWidget);
          expect(find.textContaining('Warning: This will erase all settings'),
              findsOneWidget);
          expect(find.widgetWithText(ElevatedButton, 'Reset'), findsOneWidget);
        });

    testWidgets('ProgramUpdateWidget renders its static content and button',
            (WidgetTester tester) async {
          await tester.pumpWidget(buildTestableWidget(const ProgramUpdateWidget()));

          expect(find.text('USB Detection'), findsOneWidget);
          expect(find.text('Software Update'), findsOneWidget);
          expect(find.widgetWithText(ElevatedButton, 'Install'), findsOneWidget);
        });
  });
}
