import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:machine_dashboard/api/api_exceptions.dart';
import 'package:machine_dashboard/api/api_service.dart';
import 'package:machine_dashboard/models/job.dart';
import 'package:machine_dashboard/screens/job_management/widgets/job_cards_list.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

import 'job_cards_list_test.mocks.dart';

@GenerateMocks([ApiService])
void main() {
  late MockApiService mockApiService;

  setUp(() {
    mockApiService = MockApiService();
  });

  Widget createWidgetUnderTest() {
    return MaterialApp(
      home: Scaffold(
        body: Column(
          children: [
            Expanded(
              child: JobCardsList(apiService: mockApiService),
            ),
          ],
        ),
      ),
    );
  }

  group('JobCardsList Widget Tests', () {
    testWidgets('displays CircularProgressIndicator when waiting for jobs',
            (WidgetTester tester) async {
          final completer = Completer<List<Job>>();
          when(mockApiService.fetchJobs()).thenAnswer((_) => completer.future);

          await tester.pumpWidget(createWidgetUnderTest());

          expect(find.byType(CircularProgressIndicator), findsOneWidget);
        });

    testWidgets('displays a list of jobs when fetch is successful',
            (WidgetTester tester) async {
          final jobs = [
            Job(id: '1', title: 'Test Job 1', mode: 'MIG', current: '100A'),
            Job(id: '2', title: 'Test Job 2', mode: 'TIG', current: '150A'),
          ];
          when(mockApiService.fetchJobs()).thenAnswer((_) async => jobs);

          await tester.pumpWidget(createWidgetUnderTest());
          await tester.pumpAndSettle();

          expect(find.text('Test Job 1'), findsOneWidget);
          expect(find.text('Test Job 2'), findsOneWidget);
          expect(find.byType(CircularProgressIndicator), findsNothing);
        });

    testWidgets('displays an error message when fetch fails',
            (WidgetTester tester) async {
          when(mockApiService.fetchJobs())
              .thenAnswer((_) => Future.error(ApiException('Failed to connect')));

          await tester.pumpWidget(createWidgetUnderTest());
          await tester.pumpAndSettle();

          expect(find.byIcon(Icons.wifi_off_rounded), findsOneWidget);
          expect(find.text('Connection Error'), findsOneWidget);
          expect(find.text('Retry'), findsOneWidget);
        });

    testWidgets('displays an empty message when no jobs are returned',
            (WidgetTester tester) async {
          when(mockApiService.fetchJobs()).thenAnswer((_) async => <Job>[]);

          await tester.pumpWidget(createWidgetUnderTest());
          await tester.pumpAndSettle();

          expect(find.text('No jobs found. Add a new job to get started!'),
              findsOneWidget);
        });
  });
}