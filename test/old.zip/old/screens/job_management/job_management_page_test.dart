import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:machine_dashboard/api/api_service.dart';
import 'package:machine_dashboard/models/job.dart';
import 'package:machine_dashboard/screens/job_management/job_management_page.dart';
import 'package:machine_dashboard/screens/job_management/widgets/job_cards_list.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

// Generate a mock for ApiService
import '../../widgets/my_drawer_test.mocks.dart';
@GenerateMocks([ApiService])

void main() {
  late MockApiService mockApiService;

  setUp(() {
    mockApiService = MockApiService();
  });

  // Helper function to build the widget tree with necessary dependencies
  Widget createWidgetUnderTest() {
    // When the JobCardsList inside the page tries to fetch jobs,
    // we provide a mock response to prevent errors.
    when(mockApiService.fetchJobs()).thenAnswer((_) async => <Job>[]);

    return MaterialApp(
      // home: JobManagementPage(apiService: mockApiService),
    );
  }

  group('JobManagementPage Widget Tests', () {
    testWidgets('renders all static UI elements correctly',
            (WidgetTester tester) async {
          // ARRANGE & ACT
          await tester.pumpWidget(createWidgetUnderTest());

          // ASSERT
          expect(find.text('Job Management'), findsOneWidget);
          expect(find.byIcon(Icons.search), findsOneWidget);
          expect(find.byType(TextField), findsOneWidget);
          expect(find.text('Search'), findsOneWidget);
          expect(find.byIcon(Icons.file_download), findsOneWidget);

          // FIX: Find the button by its text directly.
          expect(find.text('Import'), findsOneWidget);

          expect(find.byType(JobCardsList), findsOneWidget);
        });

    testWidgets('allows text entry in the search field',
            (WidgetTester tester) async {
          // ARRANGE
          await tester.pumpWidget(createWidgetUnderTest());

          // ACT
          await tester.enterText(find.byType(TextField), 'My Search Query');
          await tester.pump();

          // ASSERT
          expect(find.text('My Search Query'), findsOneWidget);
        });

    testWidgets('import button is tappable', (WidgetTester tester) async {
      // ARRANGE
      await tester.pumpWidget(createWidgetUnderTest());

      // ACT: FIX: Tap the button by finding its text. The test framework will
      // correctly tap the parent TextButton.
      await tester.tap(find.text('Import'));
      await tester.pump();

      // ASSERT: This test passes if the tap completes without an exception.
    });

    testWidgets('passes the provided ApiService down to JobCardsList',
            (WidgetTester tester) async {
          // ARRANGE
          await tester.pumpWidget(createWidgetUnderTest());

          // ACT
          final jobCardsListWidget =
          tester.widget<JobCardsList>(find.byType(JobCardsList));

          // ASSERT
          expect(jobCardsListWidget.apiService, mockApiService);
        });
  });
}