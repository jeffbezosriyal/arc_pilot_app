import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:machine_dashboard/api/api_exceptions.dart';
import 'package:machine_dashboard/api/api_service.dart';
import 'package:machine_dashboard/models/job.dart';
import 'package:mockito/annotations.dart';
import 'package:mockito/mockito.dart';

// 1. Generate a mock for http.Client
@GenerateMocks([http.Client])
import 'api_service_test.mocks.dart'; // 2. Import the generated file

void main() {
  late MockClient mockClient;
  late ApiService apiService;
  const baseUrl = ApiService.baseUrl;

  setUp(() {
    mockClient = MockClient();
    apiService = ApiService(client: mockClient); // 3. Inject the mock client
  });

  group('ApiService', () {
    group('fetchJobs', () {
      test(
          'returns a list of jobs when the http call completes successfully with data',
              () async {
            // ARRANGE
            final mockJobsJson = [
              {'_id': '1', 'title': 'Job 1', 'mode': 'MIG', 'current': '100A'},
            ];
            when(mockClient.get(Uri.parse(baseUrl))).thenAnswer(
                    (_) async => http.Response(json.encode(mockJobsJson), 200));

            // ACT
            final jobs = await apiService.fetchJobs();

            // ASSERT
            expect(jobs, isA<List<Job>>());
            expect(jobs.length, 1);
            expect(jobs.first.title, 'Job 1');
          });

      test('throws an ApiException for malformed JSON response', () {
        // ARRANGE: Return a success code but with invalid JSON
        when(mockClient.get(Uri.parse(baseUrl)))
            .thenAnswer((_) async => http.Response('this is not json', 200));

        // ACT & ASSERT
        expect(apiService.fetchJobs(), throwsA(isA<ApiException>()));
      });
    });

    group('addJob', () {
      test('calls client.post with correct url, headers, and body', () async {
        // ARRANGE
        final newJob = Job(title: 'New Job', mode: 'TIG', current: '90A');
        when(mockClient.post(
          any,
          headers: anyNamed('headers'),
          body: anyNamed('body'),
        )).thenAnswer((_) async => http.Response('', 201)); // Success (Created)

        // ACT
        await apiService.addJob(newJob);

        // ASSERT: Verify that client.post was called exactly once with the correct data
        verify(mockClient.post(
          Uri.parse(baseUrl),
          headers: {'Content-Type': 'application/json'},
          body: json.encode(newJob.toJson()),
        )).called(1);
      });
    });

    group('updateJobStatus', () {
      test('calls client.put with correct url, headers, and body', () async {
        // ARRANGE
        const jobId = '123';
        const isActive = true;
        when(mockClient.put(
          any,
          headers: anyNamed('headers'),
          body: anyNamed('body'),
        )).thenAnswer((_) async => http.Response('', 200));

        // ACT
        await apiService.updateJobStatus(jobId, isActive);

        // ASSERT
        verify(mockClient.put(
          Uri.parse('$baseUrl/$jobId'),
          headers: {'Content-Type': 'application/json'},
          body: json.encode({'isActive': isActive}),
        )).called(1);
      });
    });

    group('deleteJob', () {
      test('calls client.delete with the correct url', () async {
        // ARRANGE
        const jobId = '123';
        when(mockClient.delete(any))
            .thenAnswer((_) async => http.Response('', 200));

        // ACT
        await apiService.deleteJob(jobId);

        // ASSERT
        verify(mockClient.delete(Uri.parse('$baseUrl/$jobId'))).called(1);
      });
    });

    group('Exception and Response Handling', () {
      test('completes successfully for a 201 response with an empty body', () {
        // ARRANGE
        when(mockClient.delete(any))
            .thenAnswer((_) async => http.Response('', 201));

        // ACT & ASSERT
        // For a Future<void> method, we assert that it completes without throwing an error.
        // This implicitly tests that the empty body was handled correctly by _processResponse.
        expect(apiService.deleteJob('123'), completes);
      });

      test('throws ApiException on SocketException (no internet)', () {
        // ARRANGE
        when(mockClient.get(any)).thenThrow(const SocketException(''));

        // ACT & ASSERT
        expect(
            apiService.fetchJobs(),
            throwsA(predicate((e) =>
            e is ApiException && e.message.contains('No Internet'))));
      });

      test('throws ApiException on TimeoutException', () {
        // ARRANGE
        when(mockClient.get(any)).thenThrow(TimeoutException(''));

        // ACT & ASSERT
        expect(
            apiService.fetchJobs(),
            throwsA(predicate(
                    (e) => e is ApiException && e.message.contains('timed out'))));
      });

      test('throws ApiException on 400 Bad Request', () {
        // ARRANGE
        when(mockClient.get(any))
            .thenAnswer((_) async => http.Response('', 400));

        // ACT & ASSERT
        expect(
            apiService.fetchJobs(),
            throwsA(predicate(
                    (e) => e is ApiException && e.message.contains('Bad Request'))));
      });

      test('throws ApiException on 404 Not Found', () {
        // ARRANGE
        when(mockClient.get(any))
            .thenAnswer((_) async => http.Response('', 404));

        // ACT & ASSERT
        expect(
            apiService.fetchJobs(),
            throwsA(predicate(
                    (e) => e is ApiException && e.message.contains('Not Found'))));
      });

      test('throws ApiException on 500 Server Error', () {
        // ARRANGE
        when(mockClient.get(any))
            .thenAnswer((_) async => http.Response('', 500));

        // ACT & ASSERT
        expect(
            apiService.fetchJobs(),
            throwsA(predicate(
                    (e) => e is ApiException && e.message.contains('Server Error'))));
      });

      test('throws ApiException on other client error codes (default case)',
              () {
            // ARRANGE
            when(mockClient.get(any))
                .thenAnswer((_) async => http.Response("I'm a teapot", 418));

            // ACT & ASSERT
            expect(
                apiService.fetchJobs(),
                throwsA(predicate(
                        (e) => e is ApiException && e.message.contains("I'm a teapot"))));
          });
    });
  });
}